CREATE VIEW numofmatches AS SELECT player.id,
    count(match.player1) AS num
   FROM (player
     LEFT JOIN match ON ((player.id = match.player1)))
  GROUP BY player.id;
