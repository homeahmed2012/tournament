CREATE VIEW numofwins AS SELECT player.id,
    count(match.player1) AS num
   FROM (player
     LEFT JOIN match ON ((player.id = match.player1)))
  WHERE (match.winner = true)
  GROUP BY player.id;
